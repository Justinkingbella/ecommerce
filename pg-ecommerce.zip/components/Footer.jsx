import React from 'react'
import {AiFillInstagram, AiOutlineTwitter, AiFillFacebook} from 'react-icons/ai'

const Footer = () => {
  return (
    <div className='footer-container'>
    <p>
    2022 Graphics Viewer All rights reserved
    </p>
    <p className='icons'>
    <a href='https://www.instagram.com/jkrealniga/'><AiFillInstagram/></a>
    
     <a href='https://twitter.com/jkrealniga'><AiOutlineTwitter/></a>

    <a href='https://www.facebook.com/Graphic-Viewer-110791454150345'><AiFillFacebook /></a>

    </p>
    </div>
  )
}

export default Footer